'use client';
import React from 'react';
import { ApiManagement } from '@/components/dashboard/management/ApiManagement';
import { Node, NodeGroup, Api } from '@/types';

export function ApiManagementTab() {
  return <ApiManagement />;
}